#!/bin/bash

echo "My first script"


mkdir chr2_gtf
mkdir chr3_gtf
mkdir 21_gtf

grep "chr2\s" $1 >/chr2_gtf/chr2.gtf
grep "chr3\s" $1 >/chr2_gtf/chr3.gtf
grep "chr21\s" $1 >/chr2_gtf/chr21.gtf
